<?php
include('./index.php');
?>