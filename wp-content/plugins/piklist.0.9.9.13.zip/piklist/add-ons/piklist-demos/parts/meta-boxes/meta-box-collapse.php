<?php
/*
Title: Collapsed Meta Box (Closed by default.)
Post Type: piklist_demo
Order: 10
Collapse: true
Tab: Layout
Sub Tab: Meta Boxes
Flow: Demo Workflow
*/

  piklist('field', array(
    'type' => 'text'
    ,'field' => 'text-meta-box-collapsed'
    ,'label' => __('Text', 'piklist-demo')
  ));