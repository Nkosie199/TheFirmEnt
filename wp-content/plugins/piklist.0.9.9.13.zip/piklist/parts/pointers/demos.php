<?php
/*
Title: Piklist Demos
Anchor ID: #toplevel_page_piklist
Edge: bottom
Align: center
*/
?>

<p><?php printf(__('The built-in Demos highlight many Piklist features, and include code snippets you can copy and paste. Activate the Demos at %1$sPiklist > Add-ons%2$s', 'piklist'),'<a href="' . network_admin_url() . 'admin.php?page=piklist-core-addons">', '</a>');?></p>